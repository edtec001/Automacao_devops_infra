# Laboratório Prático

Experimentos reproduzíveis relacionados ao estudo.
