# Prompts Reutilizáveis

Coleção de prompts validados para futuras revisões.
