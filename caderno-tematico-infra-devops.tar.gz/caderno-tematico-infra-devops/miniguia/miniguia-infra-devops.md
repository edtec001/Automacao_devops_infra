# Miniguia de Estudo — Infraestrutura DevOps

## Resumos
A consolidar.

## Conceitos fundamentais
A consolidar.

## Glossário
Consulte `../glossario/glossario.md`.

## Prompts reutilizáveis
Consulte `../prompts/prompts-reutilizaveis.md`.
