# Laboratório Ansible
