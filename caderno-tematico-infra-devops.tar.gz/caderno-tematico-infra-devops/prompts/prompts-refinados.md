# Prompts Refinados

Registrar aqui as versões melhoradas dos prompts e o motivo de cada alteração.
