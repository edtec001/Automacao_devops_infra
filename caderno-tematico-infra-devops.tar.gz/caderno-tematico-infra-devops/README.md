# Caderno Temático — Infraestrutura DevOps

## Contexto e objetivos

Este repositório apresenta o desenvolvimento de um caderno temático dedicado ao estudo de **Infraestrutura DevOps**, utilizando o NotebookLM como ferramenta de apoio à pesquisa, organização, comparação e consolidação do conhecimento.

O objetivo é compreender como infraestrutura, automação, containers, Infrastructure as Code, orquestração, monitoramento e CI/CD se relacionam em uma arquitetura moderna de DevOps.

### Objetivos específicos

- Compreender os principais conceitos de DevOps aplicados à infraestrutura;
- Estudar automação e gerenciamento de configuração;
- Compreender containers e Docker;
- Estudar Infrastructure as Code com OpenTofu;
- Compreender os fundamentos de Kubernetes;
- Estudar monitoramento e observabilidade;
- Investigar práticas de CI/CD;
- Utilizar IA como apoio ao processo de aprendizagem;
- Documentar prompts, refinamentos e troubleshooting;
- Consolidar o conhecimento em um miniguia reutilizável.

## Estrutura

- `fontes/` — curadoria das fontes usadas no NotebookLM.
- `prompts/` — prompts iniciais, refinados e reutilizáveis.
- `cicatrizes/` — problemas encontrados, tentativas, respostas e melhorias.
- `estudos/` — conteúdo técnico organizado por assunto.
- `glossario/` — conceitos e termos principais.
- `miniguia/` — entrega final consolidada.
- `laboratorio/` — experimentos práticos.
- `evidencias/` — imagens e resultados dos experimentos.

## Curadoria inicial de fontes

- Docker — https://docs.docker.com/
- Ansible — https://docs.ansible.com/
- OpenTofu — https://opentofu.org/docs/
- Kubernetes — https://kubernetes.io/docs/
- Prometheus — https://prometheus.io/docs/

## Engenharia de Prompts e Cicatrizes

A metodologia utilizada será:

Pesquisa → Curadoria → Prompt → Resposta → Validação → Refinamento → Consolidação

As tentativas e dificuldades serão registradas em `cicatrizes/`, enquanto os prompts reutilizáveis serão mantidos em `prompts/`.

## Miniguia

O resultado consolidado será disponibilizado em:

`miniguia/miniguia-infra-devops.md`

## Laboratório

Os experimentos práticos serão organizados por tecnologia:

- Docker
- Ansible
- OpenTofu
- Kubernetes

## Status

🚧 Projeto em desenvolvimento.
