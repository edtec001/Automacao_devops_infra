# Prompts Iniciais

Registrar aqui as primeiras perguntas feitas ao NotebookLM.
