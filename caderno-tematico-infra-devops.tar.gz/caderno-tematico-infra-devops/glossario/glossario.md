# Glossário DevOps

| Termo | Definição |
|---|---|
| DevOps | A preencher |
| CI/CD | A preencher |
| IaC | A preencher |
| Container | A preencher |
| Orquestração | A preencher |
