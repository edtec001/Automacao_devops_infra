#!/usr/bin/env bash
set -euo pipefail

BASE="${HOME}/Automacao_devops_infra"
REPO="${BASE}/caderno-tematico-infra-devops"

if [[ -e "$REPO" ]]; then
  echo "ERRO: o diretório já existe: $REPO"
  echo "Para evitar sobrescrever arquivos, remova/mova o diretório ou escolha outro nome."
  exit 1
fi

mkdir -p "$BASE"
tar -xzf caderno-tematico-infra-devops.tar.gz -C "$BASE"

cd "$REPO"
git init
git branch -M main
git add .
git commit -m "chore: estrutura inicial do caderno tematico infra devops"

echo
echo "Repositorio criado com sucesso:"
echo "$REPO"
echo
git status
git log --oneline -1
