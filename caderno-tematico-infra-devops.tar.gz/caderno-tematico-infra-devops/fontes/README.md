# Curadoria de Fontes

Registrar aqui as 3 a 5 fontes abertas selecionadas e utilizadas no NotebookLM.

Para cada fonte, documentar:
- título;
- autor/organização;
- URL;
- formato;
- motivo da seleção;
- data de consulta;
