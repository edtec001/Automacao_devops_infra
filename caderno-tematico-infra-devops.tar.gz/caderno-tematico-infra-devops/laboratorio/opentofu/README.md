# Laboratório OpenTofu
