# Engenharia de Prompts

Organizar os prompts utilizados durante o estudo.

Arquivos:
- `prompts-iniciais.md`
- `prompts-refinados.md`
- `prompts-reutilizaveis.md`
