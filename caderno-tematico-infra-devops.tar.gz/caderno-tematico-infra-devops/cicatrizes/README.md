# Cicatrizes e Troubleshooting

Para cada problema, registrar:
1. contexto;
2. prompt utilizado;
3. resposta obtida;
4. problema identificado;
5. prompt refinado;
6. nova resposta;
7. validação;
8. conclusão/aprendizado.
